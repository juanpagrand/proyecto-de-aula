package com.hotel.HotelCostaAzul;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
@Controller
public class ControllerSignUp {

    @GetMapping("/sign up")
    public String SignUpPage() {
        return "sign up"; /* Spring Boot busca 'sign up.html' en 'src/main/resources/templates'*/
    }

}
