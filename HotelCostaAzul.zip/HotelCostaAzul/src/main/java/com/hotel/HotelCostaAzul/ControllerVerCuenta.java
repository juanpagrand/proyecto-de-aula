package com.hotel.HotelCostaAzul;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ControllerVerCuenta {  // Asegúrate de que el nombre de la clase es correcto y consistente
    @GetMapping("/VerCuenta")
    public String VerCuentaPage() {
        return "VerCuenta"; /* Spring Boot busca 'VerCuenta.html' en 'src/main/resources/templates' */
    }
}
