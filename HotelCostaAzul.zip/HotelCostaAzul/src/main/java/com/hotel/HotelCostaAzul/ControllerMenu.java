package com.hotel.HotelCostaAzul;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
@Controller
public class ControllerMenu {

    @GetMapping("/Menu")
    public String MenuPage() {
        return "Menu"; /* Spring Boot busca 'Menu.html' en 'src/main/resources/templates'*/
    }

}
