package com.hotel.HotelCostaAzul;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MyControllerInicio {

    @GetMapping("/")
    public String inicioPage() {
        return "incio"; /* Spring Boot busca 'inicio.html' en 'src/main/resources/templates'*/
    }





}
