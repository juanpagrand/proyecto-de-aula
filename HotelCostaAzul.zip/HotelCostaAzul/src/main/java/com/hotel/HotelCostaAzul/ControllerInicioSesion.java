package com.hotel.HotelCostaAzul;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
@Controller
public class ControllerInicioSesion {
    @GetMapping("/inicio-sesion")
    public String LoginPage() {
        return "index"; /* Spring Boot busca 'index.html' en 'src/main/resources/templates'*/
    }
}
