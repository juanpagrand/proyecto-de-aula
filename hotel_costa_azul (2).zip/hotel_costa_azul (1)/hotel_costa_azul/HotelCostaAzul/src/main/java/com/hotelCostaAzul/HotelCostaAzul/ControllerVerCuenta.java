package com.hotelCostaAzul.HotelCostaAzul;

import com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Modelo.Usuario;
import com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Servicio.UsuarioServicioImp;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ControllerVerCuenta {

    @Autowired
    private UsuarioServicioImp usuarioServicio;

    @GetMapping("/VerCuenta")
    public String verCuentaPage(HttpSession session, Model model) {

        return "VerCuenta";
    }

    @PostMapping("/VerCuenta")
    public String editarPerfil(@RequestParam String user,
                            @RequestParam String email,
                            @RequestParam String oldPassword,
                            @RequestParam String newPassword,
                            Model model) {
        Usuario usuario = usuarioServicio.obtenerPorEmail(email);

        if (usuario != null && usuario.getPassword().equals(oldPassword)) {
            usuario.setNombre(user);
            usuario.setEmail(email);

            if (newPassword != null && !newPassword.isEmpty()) {
                usuario.setPassword(newPassword);
            }

            usuarioServicio.actualizarUsuario(usuario);
            model.addAttribute("mensaje", "Su perfil ha sido actualizado con éxito");
        } else {
            model.addAttribute("error", "La contraseña antigua no coincide");
        }

        return "Menu";
    }
}
