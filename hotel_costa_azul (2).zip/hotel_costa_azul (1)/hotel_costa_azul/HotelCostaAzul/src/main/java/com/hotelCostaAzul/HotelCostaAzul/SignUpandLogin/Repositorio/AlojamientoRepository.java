package com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Repositorio;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Modelo.Alojamiento;

@Repository
public interface AlojamientoRepository extends JpaRepository<Alojamiento, Long> {
    @Query("SELECT al FROM Alojamiento al WHERE al.email = :email")
    List<Alojamiento> findRooms(String email);

    boolean existsBynHabitacion(int nHabitacion);
}


