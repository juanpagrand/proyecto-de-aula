package com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.controlador;

import com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Servicio.UsuarioServicio;
import com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.dto.UsuarioRegitroDTO;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/registro")
public class RegistroUsuarioControlador {
    private final UsuarioServicio usuarioServicio;

    public RegistroUsuarioControlador(UsuarioServicio usuarioServicio) {
        this.usuarioServicio = usuarioServicio;
    }

    @ModelAttribute("usuario")
    public UsuarioRegitroDTO retonarUsuarioRegistroDTO() {
        return new UsuarioRegitroDTO();
    }

    @GetMapping
    public String mostrarFomularioDeRegistro() {
        return "registro";
    }

    @PostMapping
    public String registrarCuentaDeUsuario(@ModelAttribute("usuario") UsuarioRegitroDTO usuarioRegitroDTO, RedirectAttributes redirectAttributes) {
        // Verifica si el email ya está registrado
        if (usuarioServicio.obtenerPorEmail(usuarioRegitroDTO.getEmail()) != null) {
            redirectAttributes.addFlashAttribute("error", "El email ya está registrado.");
            return "redirect:/registro";
        }
        usuarioServicio.guardar(usuarioRegitroDTO);
        redirectAttributes.addFlashAttribute("exito", "Se ha registrado exitosamente.");
        return "redirect:/registro";
    }
}
