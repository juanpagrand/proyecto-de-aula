package com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Servicio;

import com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Modelo.Rol;
import com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Modelo.Usuario;
import com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Repositorio.UsuarioRepositorio;
import com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.dto.UsuarioRegitroDTO;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioServicioImp implements UsuarioServicio {

    private final UsuarioRepositorio usuarioRepositorio;
    @Autowired
    private AuthenticationServicio authenticationServicio;

    public UsuarioServicioImp(UsuarioRepositorio usuarioRepositorio) {
        this.usuarioRepositorio = usuarioRepositorio;
    }

    @Override
    public Usuario guardar(UsuarioRegitroDTO registroDTO) {
        // Verificar si el email ya está registrado
        if (usuarioRepositorio.findByEmail(registroDTO.getEmail()) != null) {
            // Lanzar una excepción o retornar null para indicar que el registro falló
            return null; // O lanza una excepción personalizada
        }

        Usuario usuario = new Usuario(
                registroDTO.getNombre(),
                registroDTO.getEmail(),
                registroDTO.getPassword(),
                List.of(new Rol("ROLE_USER"))
        );
        return usuarioRepositorio.save(usuario);
    }

    @Override
    public boolean autenticar(String email, String password) {
        Usuario usuario = usuarioRepositorio.findByEmail(email);
        if (usuario != null && usuario.getPassword().equals(password)) {
            authenticationServicio.setAuthEmail(email);
            return true;
        }
        return false;
    }

    @Override
    public Usuario obtenerPorEmail(String email) {
        return usuarioRepositorio.findByEmail(email);
    }

    @Transactional
    @Override
    public void actualizarUsuario(Usuario usuario) {
        usuarioRepositorio.save(usuario);
    }






    @Override
    public List<Usuario> listarUsuarios() {
        return usuarioRepositorio.findAll();
    }
}
