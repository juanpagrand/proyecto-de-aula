package com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Servicio;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.context.annotation.SessionScope;

@Service
@Component
@SessionScope
public class AuthenticationServicio {

    private String email = "";

    public String getAuthEmail() {
        return email;
    }

    @ModelAttribute
    public void setAuthEmail(String email) {
        this.email = email;
    }
}