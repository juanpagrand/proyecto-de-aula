package com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Servicio;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;


import com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Modelo.Alojamiento;
import com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Modelo.Usuario;
import com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Repositorio.AlojamientoRepository;
import com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Repositorio.UsuarioRepositorio;

@Service
public class AlojamientoServicio {

    private final AlojamientoRepository alojamientoRepository;
    private final UsuarioRepositorio usuarioRepositorio;
    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public AlojamientoServicio(AlojamientoRepository alojamientoRepository, UsuarioRepositorio usuarioRepositorio, JdbcTemplate jdbcTemplate) {
        this.alojamientoRepository = alojamientoRepository;
        this.usuarioRepositorio = usuarioRepositorio;
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Alojamiento> obtenerHabitaciones(String email) {
        return alojamientoRepository.findRooms(email);
    }

    public boolean actualizarCamposPorTipoHabitacion(String tipoHabitacion, int dias, String email) {
        // Verificar disponibilidad antes de actualizar
        int habitacionesDisponibles = obtenerHabitacionesDisponibles(tipoHabitacion);

        if (habitacionesDisponibles <= 0) {
            System.out.println("No hay más habitaciones disponibles para el tipo: " + tipoHabitacion);
            return false; // No hay disponibilidad
        }

        // Calcular el costo
        double costo = calcularCosto(dias, tipoHabitacion);

        // Actualizar un registro disponible
        String sqlUpdate = "UPDATE alojamiento SET n_Dias = ?, costo = ?, email = ? " +
                           "WHERE non_Habitacion = ? AND (n_Dias IS NULL OR n_Dias = 0 OR costo IS NULL OR costo = 0) LIMIT 1";
        jdbcTemplate.update(sqlUpdate, dias, costo, email, tipoHabitacion);
        return true; // Se actualizó correctamente
    }

    private double calcularCosto(int nDias, String tipoHabitacion) {
        switch (tipoHabitacion) {
            case "Suite":
                return nDias * 500000;
            case "Deluxe":
                return nDias * 400000;
            default:
                return 0;
        }
    }

    public int obtenerHabitacionesDisponibles(String tipoHabitacion) {
        String sqlCheck = "SELECT COUNT(*) FROM alojamiento WHERE non_Habitacion = ? AND (n_Dias IS NULL OR n_Dias = 0 OR costo IS NULL OR costo = 0)";
        Integer habitacionesDisponibles = jdbcTemplate.queryForObject(sqlCheck, Integer.class, tipoHabitacion);
        return habitacionesDisponibles != null ? habitacionesDisponibles : 0;
    }
}
