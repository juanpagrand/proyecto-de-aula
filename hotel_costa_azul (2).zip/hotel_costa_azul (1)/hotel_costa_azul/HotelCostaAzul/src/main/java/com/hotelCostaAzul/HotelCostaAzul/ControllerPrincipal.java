package com.hotelCostaAzul.HotelCostaAzul;

import ch.qos.logback.core.model.Model;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
@Controller
public class ControllerPrincipal {

    @GetMapping("/principal")
    public String homePage(Model model) {

        return "pag"; /* Spring Boot busca 'principal.html' en 'src/main/resources/templates'*/
    }
}

