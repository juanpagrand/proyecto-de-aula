package com.hotelCostaAzul.HotelCostaAzul;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ControllerAbout {

    @GetMapping("/info")
    public String aboutPage() {
        return "info"; /* Spring Boot busca 'info.html' en 'src/main/resources/templates'*/
    }

}
