package com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Servicio.AuthenticationServicio;
import com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Servicio.UsuarioServicio;

@Controller
public class ControllerInicioSesion {

    private final UsuarioServicio usuarioServicio;
    private final AuthenticationServicio authenticationServicio;

    @Autowired
    public ControllerInicioSesion(UsuarioServicio usuarioServicio, AuthenticationServicio authenticationServicio) {
        this.usuarioServicio = usuarioServicio;
        this.authenticationServicio = authenticationServicio;
    }

    @GetMapping("/login")
    public String mostrarLogin() {
        return "index"; // Retorna la vista del formulario de inicio de sesión
    }

    @PostMapping("/login")
    public ModelAndView iniciarSesion(@RequestParam String email, @RequestParam String password) {
        if (usuarioServicio.autenticar(email, password)) {
            authenticationServicio.setAuthEmail(email); // Establece el email autenticado
            return new ModelAndView("redirect:/principal"); // Redirige al usuario
        } else {
            ModelAndView modelAndView = new ModelAndView("index");
            modelAndView.addObject("error", "Usuario o contraseña inválidos");
            return modelAndView;
        }
    }
}
