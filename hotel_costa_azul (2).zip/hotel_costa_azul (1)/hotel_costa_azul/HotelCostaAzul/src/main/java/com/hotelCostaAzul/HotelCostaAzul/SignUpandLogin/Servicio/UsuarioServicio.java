package com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Servicio;

import com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Modelo.Usuario;
import com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.dto.UsuarioRegitroDTO;
import jakarta.transaction.Transactional;
import java.util.List;

public interface UsuarioServicio {

    Usuario guardar(UsuarioRegitroDTO registroDTO);

    boolean autenticar(String email, String password);

    Usuario obtenerPorEmail(String email);

    @Transactional
    void actualizarUsuario(Usuario usuario);

    List<Usuario> listarUsuarios();
}
