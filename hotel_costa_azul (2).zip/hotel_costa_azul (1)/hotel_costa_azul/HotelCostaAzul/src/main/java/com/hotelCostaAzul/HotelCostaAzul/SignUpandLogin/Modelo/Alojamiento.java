package com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Modelo;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;


@Entity
public class Alojamiento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long IdHabitacion;

    @Column(name = "nonHabitacion")
    private String nonHabitacion;

    @Column(name = "nHabitacion", unique = true)
    private int nHabitacion;

    @Column(name = "nDias")
    private int nDias;
    
    @Column(name = "costo")
    private double costo;  

    @Column(name = "email")
    private String email;

    
    public Alojamiento(Long nUsuario, String nonHabitacion, int nHabitacion, int nDias, double costo, String email) {
        this.IdHabitacion = nUsuario;
        this.nonHabitacion = nonHabitacion;
        this.nHabitacion = nHabitacion;
        this.nDias = nDias;
        this.costo = costo;
        this.email = email;
    }

    
    public Alojamiento() {
        super();
    }

    
    public Long getIdHabitacion() {
        return IdHabitacion;
    }

    public void setIdHabitacion(Long IdHabitacion) {
        this.IdHabitacion = IdHabitacion;
    }

    public String getNonHabitacion() {
        return nonHabitacion;
    }

    public void setNonHabitacion(String nonHabitacion) {
        this.nonHabitacion = nonHabitacion;
    }

    public int getNHabitacion() {
        return nHabitacion;
    }

    public void setNHabitacion(int nHabitacion) {
        this.nHabitacion = nHabitacion;
    }

    public int getNDias() {
        return nDias;
    }

    public void setNDias(int nDias) {
        this.nDias = nDias;
    }

    public double getCosto() {
        return costo;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }

    public String getemail() {
        return email;
    }

    public void setemail(String email) {
        this.email = email;
    }

    
}