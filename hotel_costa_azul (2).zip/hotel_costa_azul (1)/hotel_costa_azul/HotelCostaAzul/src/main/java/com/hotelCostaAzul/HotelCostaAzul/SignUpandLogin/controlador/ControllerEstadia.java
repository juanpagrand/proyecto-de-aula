package com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Modelo.Alojamiento;
import com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Servicio.AlojamientoServicio;
import com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Servicio.AuthenticationServicio;


@Controller
public class ControllerEstadia {

    private final AlojamientoServicio alojamientoServicio;

    @Autowired
    private AuthenticationServicio authenticationServicio;

    public ControllerEstadia(AlojamientoServicio alojamientoServicio) {
        this.alojamientoServicio = alojamientoServicio;
    }

    @GetMapping("/estadia")
    public String estadiaPage() {
        return "estadia";
    }
    

    @PostMapping("/reservar")
    public String reservar(@RequestParam("tipoHabitacion") String tipoHabitacion,
                           @RequestParam("dias") int dias){

        

        if (tipoHabitacion == null || tipoHabitacion.isEmpty() || dias <= 0) {
            return "redirect:/error"; 
        }
// Obtener el email autenticado
    String email = authenticationServicio.getAuthEmail();
        if (email == null || email.isEmpty()) {
        return "redirect:/login"; // Redirigir al login si no hay email autenticado
}

// Guardar en la base de datos
alojamientoServicio.actualizarCamposPorTipoHabitacion(tipoHabitacion, dias, email);

return "redirect:/estadia";
    }

    @GetMapping("/mostrar")
    public String mostrar(Model model){
        //obtener lista
        List<Alojamiento> habitaciones = alojamientoServicio.obtenerHabitaciones(authenticationServicio.getAuthEmail());
        model.addAttribute("email", authenticationServicio.getAuthEmail());
        model.addAttribute("habitaciones", habitaciones);
        return "/habitacion";
    }
    
        @GetMapping("/disponibilidad")
    @ResponseBody
    public int getDisponibilidad(@RequestParam("tipoHabitacion") String tipoHabitacion) {
        // Retornar el número de habitaciones disponibles para el tipo solicitado
        return alojamientoServicio.obtenerHabitacionesDisponibles(tipoHabitacion);
    }


}